class Student:
    def __init__(self, name, age, tracks, score):
        self.name = str(name)
        self.age = int(age)
        self.tracks = list(tracks)
        self.score = float(score)

        print("My name is %s, i am %d years old. I am currently registered in %s tracks and my score is %.2f " %
              (name, age, tracks, score))

    def change_name(self, new_name):
        self.name = new_name
        print("My updated name is", self.name)

    def change_age(self, updated_age):
        self.age = updated_age
        print("My new age is", int(self.age))

    def add_track(self, updated_tracks):
        self.tracks.append(updated_tracks)

        print("My updated tracks are",
              list(self.tracks))

    def get_score(self):
        print("My score is %.2f" % self.score)


Bob = Student(name="Bob", age=26, tracks=["FE", "BE"], score=20.90)

Bob.change_name("Peter")
Bob.change_age(34)
Bob.add_track("UI/UX")
Bob.get_score()
